# Echo Point Community Center Website

This is a simple static website for Echo Point Community Center, designed with HTML and CSS.

---

## 🚀 Deployment Guide

### 🧾 Requirements
- All your HTML and CSS files saved locally
- A GitHub account (for GitHub Pages)
- A Netlify account (optional)

---

### ✅ Option 1: GitHub Pages (Free & Easy)

#### 1. Create a Repository
1. Go to [GitHub.com](https://github.com) and log in.
2. Click “New repository”.
3. Name it something like `echo-point-website`.
4. Make it public and do **not** initialize with a README.

#### 2. Upload Your Files
1. Click “Add file” → “Upload files”.
2. Upload your HTML files, CSS, and assets.
3. Click “Commit changes”.

#### 3. Deploy with GitHub Pages
1. Go to **Settings** → **Pages**.
2. Under **Source**, select:
   - **Branch:** `main`
   - **Folder:** `/root`
3. Click “Save”.
4. Your site will be live at:
   ```
   https://yourusername.github.io/echo-point-website
   ```

---

### ✅ Option 2: Netlify (Drag & Drop)

#### Drag & Drop Deployment
1. Go to [Netlify Drop](https://app.netlify.com/drop).
2. Drag and drop your unzipped project folder.
3. Netlify will deploy it and give you a `.netlify.app` URL.

#### GitHub Integration
1. On Netlify, click “Add new site” → “Import from Git”.
2. Authorize GitHub → pick your repo.
3. Set build command: `None`, publish directory: `/`
4. Click “Deploy site”.

---

### 📌 Tips
- Make sure your homepage is called `index.html`.
- Keep all HTML files and `styles.css` in the same folder.
- Match image filenames correctly.

